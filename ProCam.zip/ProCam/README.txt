ProCam v2 - Android Camera2 pro camera app.
Open in Android Studio or build with GitHub Actions. Min Android 10.
